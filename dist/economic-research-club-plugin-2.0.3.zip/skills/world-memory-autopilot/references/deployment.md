# Deployment

Use this reference only for explicit setup, deployment, canary, rollback, or user-approved repair. Normal scheduled operation follows `SKILL.md`. Its explicitly enabled additive-entities-v1 upgrade uses entity-extension.md without entering general setup/repair.

## Deterministic CLI

| Command | Exact input keys | Output purpose |
|---|---|---|
| bootstrap-plan | workspaceId | finite fresh-install action plan |
| resolve-registry-discovery | workspaceId,candidates | bounded read-only registry recovery result |
| render-scheduled-prompt | registry or {registry,entityUpgradePolicy} | compact launcher plus one configuration block; requires installed skill |
| verify-live | registry,workspaceId,toolAccess,schemaProjections,viewProjections | validation of supplied canary evidence |

## Structured CLI input shapes

| Value | Closed shape |
|---|---|
| bootstrap-plan.workspaceId | UUID string |
| resolve-registry-discovery | exact keys workspaceId,candidates; candidates is the bounded result of one exact-title Notion search plus exact candidate fetches |
| candidates[] | exact keys pageId,url,title,marker,workspaceRoot,installation; installation is null for a non-v2 candidate or has exact keys databases,views for a v2 candidate |
| installation.databases | exact keys collections,stories,storyChanges,reports; each has title,databaseUrl,parentPageId,dataSourceId,properties |
| installation.views | exact keys reportsRecent,storiesCurrent; each has name,databaseUrl,viewId,dataSourceId,displayProperties,sorts |
| render-scheduled-prompt | the Canonical registry object in notion-layout.md, or {registry,entityUpgradePolicy} with additive-entities-v1 or disabled |
| verify-live.registry/workspaceId | the exact Canonical registry plus the same workspace UUID |
| verify-live.toolAccess | exact boolean keys fetchSelf,queryDataSources,fetchPages,createPages,updatePages; all true |
| verify-live.schemaProjections | exact keys collections,stories,storyChanges,reports; each value has exact keys dataSourceId,properties |
| schemaProjections.<key>.properties | exact property-name to property-type string mapping from notion-layout.md |
| verify-live.viewProjections | exact keys reportsRecent,storiesCurrent; each value has exact keys url,dataSourceId,configuration and must match registry plus the saved-view contract |

`verify-live` validates only evidence already supplied by the caller; it does not contact Notion. Each `schemaProjections` data-source ID must match the registry, and its property mapping must include every schema property exactly once. Each `viewProjections` row must bind the registry URL to the expected data source and exact saved configuration.

## Contract map

| Contract | Operational rule |
|---|---|
| setup-separation | Fresh setup and repair are explicit user-approved modes; outside that enabled extension, scheduled operation cannot create or change schema, delete, move, adopt, or repair storage. |

## Official capability check

Before changing platform-dependent behavior, confirm the current official surfaces:

- [OpenAI Workspace Agents](https://help.openai.com/en/articles/20001143-chatgpt-workspace-agents-for-enterprise-and-business)
- [Notion MCP setup](https://developers.notion.com/guides/mcp/get-started-with-mcp)
- [Notion MCP supported tools](https://developers.notion.com/guides/mcp/mcp-supported-tools)
- [Notion databases and data sources](https://developers.notion.com/guides/data-apis/working-with-databases)
- [Notion 2025-09-03 upgrade FAQ](https://developers.notion.com/guides/get-started/upgrade-faqs-2025-09-03)
- [Notion enhanced Markdown](https://developers.notion.com/guides/data-apis/enhanced-markdown)
- [Notion MCP security](https://developers.notion.com/guides/mcp/mcp-security-best-practices)

Fetch Notion self and confirm workspace identity plus current tool access. Do not infer unavailable or undocumented guarantees.

## Fresh bootstrap

For each installation, create a new private Hub titled `World Memory · Notion Native`; do not search for or adopt pages by title. Put the `notion-native-v2` marker in the Hub, then:

1. Create four database containers, each with one initial data source: Collections, Stories, Story Changes, and Reports. Give each initial data source the non-relation properties in [notion-layout.md](notion-layout.md).
2. Resolve only each initial data source's dataSourceId. A database URL identifies its enclosing database container, not the initial data source; do not put that URL or a database ID in the registry.
3. Add the seven declared relations after all targets exist.
4. Use `notion_create_view` with the matching database create response's database URL or ID and initial `dataSourceId`; these database locators are setup-local and never enter the registry. Configure the two saved views with the exact `SHOW`, `FILTER`, and `SORT BY` strings in [notion-layout.md](notion-layout.md). The `SHOW` directives make the one view response contain every property required by the deterministic helper.
5. Perform the public CSV canary as an explicit read-only HTTPS GET to the exact registered VIX URL. Require the ordered symbols `VIX9D`, `VIX`, `VIX3M`, and `VIX6M`; do not activate a schedule if the static address is invalid or the canary cannot establish the expected source contract. Never mutate the spreadsheet.
6. Read back the Hub locator, each data source's sole registry field `dataSourceId`, every property name/type, and each saved view's returned view ID, data-source binding, display properties, filters, and sorts. Form the queryable HTTPS view URL from the matching database URL plus that view ID as the sole `v` parameter, validate it, and persist only that URL in the registry.
7. Emit and validate the complete `notion-native-v2` registry, including its immutable `marketSources`, then regenerate and embed the scheduled prompt.

Keep setup finite. Do not save provisional addresses, credentials, OAuth tokens, cookies, or connector responses in the package or prompt.

## Schedule

Schedule creation defaults to a six-hour interval (`creationCadenceMinutes=360`). Never claim that an existing active schedule changed until its live setting is verified. Each actual cadence defines its own report window; Story integration becomes due after 345 elapsed minutes so a nominal six-hour reservation tolerates scheduler delivery variance without becoming a briefing.

The scheduled prompt normally embeds the validated registry and the normal operation boundaries. If both that registry and a complete valid ChatGPT-memory registry are absent, the caller may search Notion exactly once for the exact Hub title, fetch the exact-title candidates, and pass bounded observations to `resolve-registry-discovery`. The helper selects only one workspace-root candidate with the exact v2 marker and exact four-database plus two-view structure; `text` from the connector is normalized only as the transport alias of logical `rich_text`. It returns a recovered registry or one bounded not-found, ambiguous, or structure-mismatch error. It does not contact Notion, write, repair, or persist anything. After this pre-operation recovery boundary, search and broad scans are forbidden again.

Connector Action Constraints permit `notion_query_data_sources` only for the registered saved-view workflow, and the prompt must always send the view-shaped `data.mode=view` input. Do not use the SQL-shaped input, SQL fallback, runtime view mutation, schema changes, deletion, movement, or broad repair.

## Repair and migration

Enter repair or migration only after an explicit request identifies the target and desired change. Read the target first, show a bounded plan and rollback path, obtain approval for schema or destructive work, and verify the changed invariant afterward. Never adopt a title match automatically. A fresh installation never reads or modifies an older Hub.

To migrate any v0.11.x installation, pause its schedule first. Under explicit setup permission, retain the four unchanged database schemas, read back the exact `Reports Recent` and `Stories Current` bindings/configurations, explicitly regenerate the complete `notion-native-v2` registry and scheduled prompt, and run both the saved-view and public CSV canaries in read-only mode; then resume only after both canaries pass. Existing Reports and Stories remain readable, and same-window reuse remains type-agnostic across the boundary. Normal scheduled operation cannot perform this migration, infer view URLs from titles, or mutate its embedded registry.

## Live canary

Use a new test Hub. Verify workspace binding, four schema projections, both saved-view projections, the read-only public CSV source and exact ordered VIX symbols, a SQL-free Reports view read, first Collection and Report, same-window reuse, a partial-source run, and a due Stories view plus Story/Story Change run. Inspect that pages are natural Markdown, use the approved Report layout, and preserve a logical leading H1 through the `<empty-block/>` transport adapter. Measure connector calls, ordinary read-backs, and elapsed time; report the observed values rather than promising unmeasured targets. Do not use an existing operating Hub as the canary.

## Rollback

Stop the new schedule, retain the new Hub for diagnosis, and let the user decide whether to reactivate an older schedule. Do not delete either Hub or combine their data automatically.


## Repeated feed transport failures (manual repair)

Inspect the current execution environment's network policy before probing. The fixed RSS.app feeds require HTTPS access to `rss.app` from the runtime executing `collect-feeds`; access in a user's browser does not establish runtime access. If the permitted destinations exclude RSS.app, report that missing access as a collection blocker. Do not disable TLS checks, alter proxies, tunnel requests, change feed hosts, or replace the approved transport with web/browser/connector fetching.

For an explicit diagnosis request, inspect the original typed transport exception through a bounded request to a configured feed. Never disclose proxy values, credentials, or raw exception text. Distinguish DNS, TLS certificate, HTTP status, connection reset/refusal, and timeout. Do not attribute a proxy request timeout to direct DNS failure alone. Timeouts do not prove that the provider is down. The collector unwraps typed `URLError.reason` values and emits safe codes; opaque string reasons remain `feed_fetch_urlerror`. HTTP 408/425/429 and 5xx, temporary DNS, timeouts, and connection reset/refusal are potentially retryable; certificate, permission, permanent DNS, and other HTTP failures are not.

Preserve source outcome fields and successful feeds. Do not add hidden retries, alter the resolved window, or persist raw diagnostics. If a network prerequisite is missing, distinguish code improvements from live recovery: save and test the authorized skill fix, identify the outstanding access requirement, and do not claim that collection is restored. A changed failure cause or newly identified shared blocker is a meaningful update even when earlier runs reported failures. Keep scheduled no-repair and zero-success no-write rules intact.


## Publisher-search deployment

Render the current scheduled prompt with render-scheduled-prompt and update the existing World Memory automation prompt, preserving its registry, active state, cadence and timezone. Verify its configuration preserves the exact registry and the installed skill uses publisher-web-search-v5 with no RSS success gate. Do not create a replacement automation. This authorized source change does not modify Notion schemas. Legacy RSS diagnostics above apply only to explicit RSS tasks.

## Additive rollout and compact launcher

Preserve the exact existing registry and schedule identity. Render the current prompt to include seven market access flags and `entityUpgradePolicy: additive-entities-v1`. Apply only an explicitly authorized schedule update; installing a local skill does not modify a cloud schedule or its connector permissions. Fresh setup first completes the core four-DB bootstrap, then runs the same bounded entity extension. Validate newly added structure with entity-extension-plan; verify-live remains the core canary. Disabling the extension preserves its records.

The v0.19 launcher deliberately delegates operating rules to the installed SKILL.md and its references. Do not schedule it in an environment that cannot load that skill. The single `<world_memory_config>` JSON block carries registry, entityUpgradePolicy and marketToolAccess. Replace null access flags using current tool discovery; build market-data-plan input as {registry: config.registry, toolAccess: config.marketToolAccess}. Installing a local release does not update an existing remote prompt.


The v0.22 launcher requires mandatory entityContext plan validation and the
prepare-report and complete-entity-review commands. During an authorized update, regenerate the
existing automation prompt after installing the skill; preserve its exact
registry, policy, active state, cadence and timezone. Verify both required-review
lines and internal-completion lines in the live prompt. Older validation inputs
are deliberately rejected rather than silently disabling required review.


The v0.23 news update uses one cached FinancialJuice RSS request as optional
discovery input, broad topic searches, and soft event-diversity guidance. Update
the existing launcher after saving this skill; preserve registry, entity policy,
cadence, timezone and enabled state. Do not alter market-data behavior.

The v0.24 news update restores the four validated RSS.app XML feeds listed in
publisher-web-search.md, with separate per-feed cached outcomes and the existing
First Squawk timestamp correction. Keep unusual_whales disabled after HTTP 502.
Update the existing launcher only; preserve market sources, registry and schedule.
